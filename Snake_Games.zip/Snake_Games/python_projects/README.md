# python_projects
Repository for (codebasics youtube channel python projects)
[Click here to watch project videos on Codebasics Youtube Channel](https://www.youtube.com/playlist?list=PLeo1K3hjS3usVcPj6osMx1tNkARllcRhZ)

### 1. Snake and apple game
In this project we have build a complete snake and apple video game using pygame module. 

[Click here to go to this project](https://github.com/codebasics/python_projects/tree/main/1_snake_game)


### 2. Document text extraction using OCR (Coming up soon)


